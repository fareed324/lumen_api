<?php

return [
    'driver' => 'smtp',
    'host' => 'sandbox.smtp.mailtrap.io',
    'port' => 2525,
    'from' => [
        'address' => 'mr.adalbutt@gmail.com',
        'name' => 'fareed',
    ],
    'encryption' => 'tls',
    'username' => 'ee443e47857c47',
    'password' => '3d8a076bb521d6',
];
// MAIL_MAILER=smtp
// MAIL_HOST=sandbox.smtp.mailtrap.io
// MAIL_PORT=2525
// MAIL_USERNAME=76a312156c9ee4
// MAIL_PASSWORD=9064bc89d0b067
// MAIL_ENCRYPTION=tls

// Adil

// MAIL_MAILER=smtp
// MAIL_HOST=sandbox.smtp.mailtrap.io
// MAIL_PORT=2525
// MAIL_USERNAME=ee443e47857c47
// MAIL_PASSWORD=3d8a076bb521d6
// MAIL_ENCRYPTION=tls