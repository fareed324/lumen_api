<?php

namespace App\Validators;

use Illuminate\Support\Facades\Validator;

class UserValidator
{
    public static function validateRegistration(array $data)
    {
        $rules = [
            'name' => 'required|string|between:2,100',
            'email' => 'required|string|email|max:100|unique:users',
            'password' => 'required|string|min:6',
        ];

        return Validator::make($data, $rules);
    }
}

//  function rules()
// {
//     return [
//         'name' => 'required|string|between:2,100',
//         'email' => 'required|string|email|max:100|unique:users',
//         'password' => 'required|string|min:6',
//     ];
// }
