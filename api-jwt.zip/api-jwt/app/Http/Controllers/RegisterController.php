<?php
namespace App\Http\Controllers;

use App\Models\Register;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class RegisterController extends Controller
{
    public function index()
    {
        $users = register::all();
        return response()->json($users);
    }

    public function show($id)
    {
        $user = register::findOrFail($id);
        return response()->json($user);
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
        ]);
        $user = register::create($request->all());
        return response()->json($user, Response::HTTP_CREATED);
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users,email,' . $id,
            'password' => 'required|min:6',
        ]);
        $user = register::findOrFail($id);
        $user->update($request->all());
        return response()->json($user, Response::HTTP_OK);
    }

    public function destroy($id)
    {
        register::findOrFail($id)->delete();
        return response()->json(null, Response::HTTP_DELETE);
    }
}