<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;

class ForgotPasswordController extends Controller
{
    public function sendResetLink(Request $request)
    {
        
        $this->validate($request, [
            'email' => 'required|email',
        ]);

        $user = User::where('email', $request->email)->first();
        // dd($user);
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        $token = Str::random(60);
        $user->password_reset_token = $token;
        $user->save();
        
        // Send password reset email
        // Mail::send('emails.reset_password', ['password_reset_token' => $token], function ($message) use ($user) {
        //     $message->to($user->email);
        //     $message->subject('Reset Your Password');
        //    $message->with('token', $token);
        // });

     

        $resetLink = '<a href="http://localhost:8004/emails.reset_password?token='.($token).'">Reset </a>';
        $tokedetails=htmlspecialchars($resetLink);
        
        Mail::raw("Your password reset token: $token", function ($message) use ($user) {
            $message->to($user->email);
            $message->subject('Password Reset Token');
        });

        // dd($message);
        return response()->json(['message' => 'Password reset link sent'], 200);
    }

    public function sendOnboardingClientInfo($user, $password)
    {
        $this->to = $user->email;
        $this->subject = "[Ticket Title: $user->name]";
        $this->view = 'emails.onboard_client.onboard';
        $this->data = compact('user', 'password');
        return $this->deliver();
    }

    public function showdata()
    {
        $users = User::all();
        return view('users.index', compact('users'));
    }
}
