<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;

class Reset_Pass_Controller extends Controller
{
    public function reset(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email',
            'password_reset_token' => 'required',
            'password' => 'required|confirmed|min:6',
        ]);

        $email = $request->input('email');
        $token = $request->input('password_reset_token');
        $password = $request->input('password');

        $resetRecord = DB::table('users')
            ->where('email', $email)
            ->where('password_reset_token', $token)
            ->first();

        if (!$resetRecord) {
            return response()->json(['message' => 'Invalid password reset token'], 422);
        }

        // Update user's password
        DB::table('users')
            ->where('email', $email)
            ->update(['password' => Hash::make($password)]);

        // Delete password reset record
        // DB::table('users')
        //     ->where('email', $email)
        //     ->delete();

        // Log in the user or perform additional actions

        // Return response or redirect to success page
        return response()->json(['message' => 'Password reset successful']);
    }

    public function index()
    {
        $users = User::all();
        return view('users.index', compact('users'));
    }

    public function getlink() {
        $email = $request->input('email');
        $token = $request->input('password_reset_token');
       
        $link = DB::table('users')
        ->where('email', $email)
        ->where('password_reset_token', $token)
        ->get();
       return compact('link');
    //    dd($link);
    }
}
