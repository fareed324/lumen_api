<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class register extends Model
{
    protected $fillable = [
        'first_name',
        'last_name',
        'username', 
        'mobile_1',
        'mobile_2',
        'city',
        'country',
        'address',
        'ip_address_last_login',
        'email', 
        'password',
        'remember_token',
        'status'
    ];

    protected $hidden = [
        'password',
    ];
}
