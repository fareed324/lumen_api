
<body>
  <h1>Are you Forget Password?</h1>
    <h2>Password Reset Requested.</h2>
    <a href="" type="button" class="btn btn-primary">RESET PASSWORD</a>
    <p>Your password reset token: <?php echo e($token); ?></p>

  </body>
  <?php /**PATH D:\lumen\api-jwt\resources\views/emails/reset_password.blade.php ENDPATH**/ ?>