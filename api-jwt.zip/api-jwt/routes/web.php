<?php

/** @var \Laravel\Lumen\Routing\Router $router */
use Illuminate\Support\Facades\Route;
use Laravel\Lumen\Routing\Router;
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    // return $router->app->version();
    echo "Working Fine Jwt with Api";
});

/////////////////////////////////////////////////////////
//             Authentication Register-Login          //
///////////////////////////////////////////////////////

$router->post( '/login', 'AuthController@login');
$router->post( '/register', 'AuthController@register' );

/////////////////////////////////////////////////////////
//            AUTHENTICATED ROUTES                    //
///////////////////////////////////////////////////////

$router->group(
  [
    'middleware' => 'auth',
  ], function( $router ) {
    $router->post( '/logout', 'AuthController@logout' );
    $router->get( '/refresh', 'AuthController@refresh' ); 
    $router->post( '/refresh', 'AuthController@refresh' );
});

/////////////////////////////////////////////////////////
//                Forget-Password                     //
///////////////////////////////////////////////////////

$router->post('password/email', 'ForgotPasswordController@sendResetLink');
$router->post('password/reset', 'Reset_Pass_Controller@reset');

$router->post('show', 'ForgotPasswordController@showdata');
$router->get('link','Reset_Pass_Controller@getlink');

/////////////////////////////////////////////////////////
//                Register                            //
///////////////////////////////////////////////////////

  $router->get('/all_user', 'RegisterController@index');
  $router->get('/user/{id}', 'RegisterController@show');
  $router->post('/create_user', 'RegisterController@store');
  $router->post('/update_user/{id}', 'RegisterController@update');
  $router->delete('/delete_user/{id}', 'RegisterController@destroy');

